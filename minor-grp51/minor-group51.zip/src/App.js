import React from 'react'
import Login from './Components/Login.js'

class App extends React.Component {
  render() {
    return (
      <Login/>
    )
  }
}

export default App;
