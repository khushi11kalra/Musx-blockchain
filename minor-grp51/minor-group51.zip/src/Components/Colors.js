export const COLORS = {
    white: 'rgb(240,240,230)',
    brown: '#FFACC7', //ffdd95
    highlight: '#BCDAB4', //
    black: 'rgb(4,16,13)', //)FEFCF3
    blue :'#143642', //   00ABB3
    blurWhite: 'rgb(255,255,255,0.75)',
    blurBlack: 'rgb(0,0,0,0.75)', //

  }